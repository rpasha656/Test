export enum FileExtension {
    txt = 1,
    pdf = 2,
    xlsx = 3,
    xls = 4,
    docx = 5,
    doc = 6,
    csv = 7,
    ppt = 8,
    pptx = 9,
    rtf = 10,
    tif = 11,
    zip = 12
}
